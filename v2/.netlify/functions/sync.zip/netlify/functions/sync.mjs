
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/sync.mts
import { getStore } from "@netlify/blobs";
var sync_default = async (req, _context) => {
  const url = new URL(req.url);
  const key = url.searchParams.get("key");
  if (!key || key.length < 32 || key.length > 128) {
    return new Response(JSON.stringify({ error: "invalid_key" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
  if (!/^[a-f0-9]+$/i.test(key)) {
    return new Response(JSON.stringify({ error: "invalid_key_format" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
  const store = getStore({ name: "plangym-user-data", consistency: "strong" });
  try {
    if (req.method === "GET") {
      const data = await store.get(key, { type: "json" });
      if (!data) {
        return new Response(JSON.stringify({ error: "not_found" }), {
          status: 404,
          headers: { "Content-Type": "application/json" }
        });
      }
      return new Response(JSON.stringify(data), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }
    if (req.method === "POST") {
      const body = await req.text();
      if (body.length > 10 * 1024 * 1024) {
        return new Response(JSON.stringify({ error: "too_large" }), {
          status: 413,
          headers: { "Content-Type": "application/json" }
        });
      }
      let parsed;
      try {
        parsed = JSON.parse(body);
      } catch {
        return new Response(JSON.stringify({ error: "invalid_json" }), {
          status: 400,
          headers: { "Content-Type": "application/json" }
        });
      }
      const wrapped = {
        ...parsed,
        _syncedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      await store.setJSON(key, wrapped);
      return new Response(JSON.stringify({ ok: true, syncedAt: wrapped._syncedAt }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }
    return new Response(JSON.stringify({ error: "method_not_allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    console.error("Sync error", err);
    return new Response(JSON.stringify({ error: "server_error", message: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
export {
  sync_default as default
};
